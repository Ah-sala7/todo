import 'package:flutter/material.dart';
import 'package:todo_c8_online/database/model/task.dart';

class TaskWidget extends StatelessWidget {
Task task;
TaskWidget(this.task);
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 4,horizontal: 8),
      padding: EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        children: [
          Container(
            decoration: BoxDecoration(
              color: Theme.of(context).primaryColor,
              borderRadius: BorderRadius.circular(18),
            ),
            width: 4,
            height: 64,
          ),
          Expanded(child: Container(
            padding:EdgeInsets.symmetric(horizontal: 12),
              child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(task.title??'',style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).primaryColor
                ),),
                Text(task.desc??'',style: TextStyle(
                  fontSize: 12
                ),)
              ],
            ),
          )),
          Container(
            padding: EdgeInsets.symmetric(vertical: 8,horizontal: 24),
            decoration: BoxDecoration(
              color: Theme.of(context).primaryColor,
              borderRadius: BorderRadius.circular(18),
            ),
            child: ImageIcon(AssetImage('assets/images/ic_check.png'),color: Colors.white,),
          ),

        ],
      ),
    );
  }
}
