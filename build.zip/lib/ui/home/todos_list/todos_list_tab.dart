import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:todo_c8_online/database/TasksDao.dart';
import 'package:todo_c8_online/providers/AuthProvider.dart';
import 'package:todo_c8_online/ui/home/todos_list/TaskWidget.dart';

class TodosListTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var authProvider = Provider.of<AuthProvider>(context);
// Rest of your code

    return Column(
      children: [
        Expanded(
            child: FutureBuilder(
          future: authProvider.databaseUser != null
              ? TasksDao.getAllTasks(authProvider.databaseUser!.id!)
              : Future.error('User is not logged in'),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasError) {
              return Center(
                child: Column(children: [
                  Text('Something went wrong ,please try again'),
                  ElevatedButton(onPressed: () {}, child: Text('try again')),
                ]),
              );
            }
            var tasksList = snapshot.data;
            return ListView.builder(
              itemBuilder: (context, index) {
                return TaskWidget(tasksList![index]);
              },
              itemCount: tasksList?.length ?? 0,
            );
          },
        ))
      ],
    );
  }
}
