import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:todo_c8_online/database/model/task.dart';
import 'package:todo_c8_online/database/my_database.dart';

class TasksDao{
  static CollectionReference<Task> getTasksCollection(String uid){
    return MyDataBase.getUsersCollection().
    doc(uid).collection(Task.collectionName).
    withConverter(
      fromFirestore: (snapshot, options) => Task.fromFireStore(snapshot.data()),
      toFirestore: (task, options) => task.toFireStore(),);
  }
  static Future<void> createTask(Task task,String uid)async{
    var docref=getTasksCollection(uid).doc();
    task.id=docref.id;
    return docref.set(task);


  }
  static Future<List<Task>> getAllTasks(String uid)async{
    var tasksSnapshot =await getTasksCollection(uid).get();
    var tasksList =tasksSnapshot.docs.
    map((snapshot) => snapshot.data()).
    toList();
    return tasksList;
  }
}